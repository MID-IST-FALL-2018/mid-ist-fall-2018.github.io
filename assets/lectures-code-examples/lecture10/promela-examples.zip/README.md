# Files summary

The files `arithmetic-operations.pml`, `control-statements.pml`, `datatypes-enumerations.pml`, `hello-world.pml`, `message-passing.pml` and `processes.pml` are simply example models to learn the basics of Promela. The file `counter.pml` contains a simple model including two processes that increment a shared variable in an unsafe way. We use assertions to identify the possible data races. The file `distributed-building-firm.pml` contains a solution to the [building firm assignment](https://github.com/MID-IST-FALL-2018/building-firm/blob/master/BuildingFirm.java) using rendez-vous channels instead of monitors (this code is inspired by the [Introduction to shared memory concurrency by K.V.S Prasad](http://www.cse.chalmers.se/edu/year/2017/course/TDA384_LP1/files/exercises/promela-tutoria1l-shared-mem-conc.pdf)). We also use several LTL formulae to assess its correctness. Finally, the file `proxy.pml` contains a model of a system consisting of several clients which communicate to servers through a proxy. This example is taken from the course [TDA294 - Formal Methods for Software Development at Chalmers University of Technology](http://www.cse.chalmers.se/edu/year/2017/course/TDA294_Formal_Methods_for_Software_Development/Exercises/TemporalModelChecking/Exercises_TemporalModelChecking.html).

# Running Promela/SPIN examples

The following commands assume that you have installed SPIN (you can find
download and install instructions
[here](http://spinroot.com/spin/Man/README.html))

To simulate the models you can simply run

```bash
$ spin <filename>
```

In order to verify the LTL properties in the models you may run

```bash
$ spin -search -ltl <property_name> <filename>
```

When SPIN finds a counter-example trace for a property you are checking you may run the trace with

```bash
$ spin -t <filename>
```
Note that the name of the property is not necessary.

You may use some flags to output more information while running the trace or during simulation such as global variables (`-g`), local variables (`-l`) or verbose output (`-v`). See the `man` pages or the [quick reference](http://spinroot.com/spin/Doc/spin-quick-reference.pdf).
