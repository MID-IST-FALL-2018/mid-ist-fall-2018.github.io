package com.mid.math;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mid.math.Server.RequestOperation;
import com.mid.math.Client.ResponseServer;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.testkit.javadsl.TestKit;

public class MathServerTest {
  static ActorSystem system;

  // Start the actor system
  @BeforeClass
  public static void start() {
      system = ActorSystem.create();
  }

  // Shutdown the actor system
  @AfterClass
  public static void shutdown() {
      TestKit.shutdownActorSystem(system);
      system = null;
  }

  @Test
  public void testSUM() {
    // Create a dummy actor, testProb, as synthetic client
    final TestKit testProbe = new TestKit(system);
    // Create a server actor
    final ActorRef server = system.actorOf(Server.props());
    // Tell server to compute x+y
    int x = 1;
    int y = 2;
    server.tell(new RequestOperation(x, y, BinaryOperation.SUM), testProbe.getRef());
    // Check that the server replies with the expected message type
    ResponseServer rs = testProbe.expectMsgClass(ResponseServer.class);
    // Check that the content of the message is the correct result of the operation
    assertEquals(x+y, rs.response);
  }

  @Test
  public void testSUB() {
    // Create a dummy actor, testProb, as synthetic client
    final TestKit testProbe = new TestKit(system);
    // Create a server actor
    final ActorRef server = system.actorOf(Server.props());
    // Tell server to compute x-y
    int x = 0;
    int y = 23;
    server.tell(new RequestOperation(x, y, BinaryOperation.SUB), testProbe.getRef());
    // Check that the server replies with the expected message type
    ResponseServer rs = testProbe.expectMsgClass(ResponseServer.class);
    // Check that the content of the message is the correct result of the operation
    assertEquals(x-y, rs.response);
  }

  @Test
  public void testMUL() {
    // Create a dummy actor, testProb, as synthetic client
    final TestKit testProbe = new TestKit(system);
    // Create a server actor
    final ActorRef server = system.actorOf(Server.props());
    // Tell server to compute x*y
    int x = 4;
    int y = 5;
    server.tell(new RequestOperation(x, y, BinaryOperation.MUL), testProbe.getRef());
    // Check that the server replies with the expected message type
    ResponseServer rs = testProbe.expectMsgClass(ResponseServer.class);
    // Check that the content of the message is the correct result of the operation
    assertEquals(x*y, rs.response);
  }
}
