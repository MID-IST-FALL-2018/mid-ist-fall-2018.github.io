package com.mid.math;

enum BinaryOperation {SUM, SUB, MUL, PI_DIGITS};
