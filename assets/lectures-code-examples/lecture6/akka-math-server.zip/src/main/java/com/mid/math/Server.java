package com.mid.math;

import com.mid.math.Client.ResponseServer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Server extends AbstractActor {

  /***********/
  /** State **/
  /***********/
  // Empty


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props() {
    return Props.create(Server.class, () -> new Server());
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Server() {}


  /**************/
  /** Messages **/
  /**************/
  static public class RequestOperation {
    int x,y;
    BinaryOperation op;

    public RequestOperation(int x, int y, BinaryOperation op) {
      this.x  = x;
      this.y  = y;
      this.op = op;
    }
  }

  static public class Shutdown {
    public Shutdown() {}
  }


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // Request to perform an operation
    .match(RequestOperation.class, ro -> {
      int result = Integer.MIN_VALUE;
      switch (ro.op) {
        case SUM:
          // try{Thread.sleep(5000);}catch(Exception e){} // Delay for task
          result = ro.x + ro.y;
          break;
        case SUB:
          result = ro.x - ro.y;
          break;
        case MUL:
          result = ro.x * ro.y;
          break;
      }
      // Reply client with the result
      getSender().tell(new ResponseServer(result), getSelf());
    })
    // Shutdown the server
    .match(Shutdown.class, x -> {
      System.out.println("Shutting down server: Hasta la vista 😎");
      getContext().stop(getSelf());
    })
    .build();
  }
}
