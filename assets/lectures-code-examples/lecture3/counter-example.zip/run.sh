#!/bin/bash
COUNT=0
MAX=10
while [ $COUNT -lt $MAX ]; do
    java Counter
    let COUNT=COUNT+1
done
