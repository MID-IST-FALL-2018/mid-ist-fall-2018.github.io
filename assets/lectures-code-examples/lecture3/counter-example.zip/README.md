# Counter

Simple example of two threads updating a shared variable (file `Counter.java`).
The file `Counter.jad` contains a decompiled version of the code, showing that
the operation `counter++` is not atomic, and, consequently, may produce data
races that corrupt the result.

# Running the code

To run the code compile with

```bash
$ javac Counter.java
```

and run with

```bash
$ java Counter
```

The file `run.sh` is a simple script that runs the program 10 times.

# Decompiling

To decompile the code, first download the tool
[jad](https://varaneckas.com/jad/) and execute the following command

```bash
$ jad -af Counter.class
```

If you get an error message similar to

```
Parsing Counter.class...The class file version is 54.0 (only 45.3, 46.0 and 47.0 are supported)
```

is because you are compiling for a version of java not supported by `jad`.  A
possible solution is to compile `Counter.java` for JDK 1.6  as follows

```bash
$ javac -source 1.6 -target 1.6 Counter.java
```
