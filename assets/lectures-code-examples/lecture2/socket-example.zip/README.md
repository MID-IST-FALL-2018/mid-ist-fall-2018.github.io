# Sockets Example

Official Java example on using sockets  <https://docs.oracle.com/javase/tutorial/networking/sockets/index.html>

# Running the code

To run the code first compile all files with

```bash
$ javac *.java
```
Then run the `EchoServer` in a port, e.g., 5000:

```bash
$ java EchoServer 5000
```

Now, run the `EchoClient` in a different terminal specifying the localhost and
the same port as in the previous command

```bash
$ java Client 127.0.0.1 5000
```

Finally, you can enter string through the standard input.
