# Java RMI example

Example of code on using Java Remote Method Invocation (RMI). The example is an
implementation of the [official Java socket
example](https://docs.oracle.com/javase/tutorial/networking/sockets/index.html)
but using Java RMI.

This example contains 3 files:

* `Echo.java` - An remote interface declaring the remote methods that a server
  oft this type must implement. In this example, the only method is `String
  echo(String message)`.

* `Server.java` -  A server program that implements the remote interface
  `Echo.java`. The implementation is very simple, the server simply returns the
  parameter `message`. It also shows how to upload the `Server` program to
  the RMI registry.

* `Client.java` - A client program that makes remote method invocations to the
  methods in `Echo.java`. Concretely, it calls the `echo(String message)` method
  with a `String` read from the standard input. It also shows how to download the `Server` stub from the RMI registry.

# Running the code

To run the code first compile all files with

```bash
$ javac *.java
```

Secondly, you must run an instance of the RMI registry (it is important to run
this command in the same directory where the the .class files are, otherwise you
must specify the classapth)

```bash
$ rmiregistry
```

Thirdly, run the server in a different terminal

```bash
$ java Server
```

Finally, in a different terminal run the client(s)

```bash
$ java Client
```
