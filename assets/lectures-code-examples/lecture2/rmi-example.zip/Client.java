// RMI imports
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.RemoteException;
import java.rmi.NotBoundException;

// IO imports
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Client {

  private Client() {}

    public static void main(String[] args) {

      try (
          // Standard input
          BufferedReader stdIn =
              new BufferedReader(
                  new InputStreamReader(System.in))
      ) {
        // Get reference to registry (supposedly) in default port 1099
        Registry registry = LocateRegistry.getRegistry();
        // Get remote object's reference
        Echo stub = (Echo) registry.lookup("Echo");

        String userInput;
        while((userInput = stdIn.readLine()) != null) {
          // Remote method invocation
          String response = stub.echo(userInput);
          // Printing the result
          System.out.println("echo: " + response);
        }
      // Exception handling
      } catch (NotBoundException | RemoteException e) {
        System.err.println("Client remote exception: " + e.toString());
        System.exit(1);
      } catch(IOException e) {
        System.err.println("Client IO exception: " + e.toString());
        System.exit(1);
      }
    }
  }
