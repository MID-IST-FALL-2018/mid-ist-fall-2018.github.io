// RMI imports
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.rmi.AlreadyBoundException;

public class Server implements Echo {

  public Server() {}

    public String echo(String message) {
      return message;
    }

    public static void main(String args[]) {

      try {
        // Create an server instance of the remote object
        Server server = new Server();
        // Create a stub for the server in port 5000
        Echo stub = (Echo) UnicastRemoteObject.exportObject(server, 5000);
        // Get reference to a registry
        Registry registry = LocateRegistry.getRegistry();
        // Bind the remote object's stub in the registry
        registry.bind("Echo", stub);

        // Report that the server startup correctly
        System.err.println("Server ready");
      // Exception handling
      } catch (AlreadyBoundException | RemoteException e) {
        System.err.println("Server remote exception: " + e.toString());
        System.exit(1);
      }
    }
  }
