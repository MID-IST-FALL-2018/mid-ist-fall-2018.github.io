# Mutex Monitor

`MutexMonitor.java` contains an example of implementing a mutex monitor. Note
that this program is not executable. However, it can be compiled with

```bash
$ javac MutexMonitor.java
```

The code presented in this example may be used as an inspiration for the monitors to be implemented in the second [programming assignment](https://mid-ist-fall-2018.github.io/assignments.html).
