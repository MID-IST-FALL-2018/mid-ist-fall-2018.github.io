import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;


class MutexMonitor {
   final Lock lock = new ReentrantLock();
   final Condition cond  = lock.newCondition();

   Boolean full = false;

   public void enter() throws InterruptedException {
     lock.lock(); // Atomic method enter
     try {
       while (full) { // Always re-check condition and spurious wake-ups,
         cond.await(); // If the monitor is full, wait on `cond`
       }
       full = true; // Set he monitor as full
     } finally {
       lock.unlock(); // Atomic method enter (always release the lock)
     }
   }

   public void leave() throws InterruptedException {
     lock.lock(); // Atomic method enter
     try {
       full = false; // Set he monitor as empty
       cond.signal(); // Signal any potential waiting thread
     } finally {
       lock.unlock(); // Atomic method enter (always release the lock)
     }
   }
 }
