class CounterSynchronizedBlock {
  final int PEOPLE = 1000;
  Counter c = new Counter(); // Thread-safe counter

  public CounterSynchronizedBlock() {
    try {
      Gate east = new Gate();
      Gate west = new Gate();

      east.start();west.start();
      east.join();west.join();

      System.out.println("counter = " + c.getCounter());

    } catch (InterruptedException e) {
      System.out.println(e);
    }

  }

  public static void main(String[] args) {
    new CounterSynchronizedBlock();
  }

  class Gate extends Thread {
    public void run() {
      for (int i = 0; i < PEOPLE; i++) {
        c.inc();
      }
    }
  }

  class Counter {
    private int counter;
    private Object lock = new Object();

    public Counter() {
      counter=0;
    }

    public void inc() {
      synchronized(lock) {
        counter++;
      }
    }

    public int getCounter() {
      return counter;
    }
  }
}
