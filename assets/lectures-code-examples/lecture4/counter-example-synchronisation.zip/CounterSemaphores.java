import java.util.concurrent.Semaphore; // Semaphores library for Java

class CounterSemaphores {
  int counter = 0;
  final int PEOPLE = 1000;
  Semaphore sem = new Semaphore(1);

  public CounterSemaphores() {
    try {
      Gate east = new Gate();
      Gate west = new Gate();

      east.start();west.start();
      east.join();west.join();

      System.out.println("counter = " + counter);

    } catch (InterruptedException e) {
      System.out.println(e);
    }

  }

  public static void main(String[] args) {
    new CounterSemaphores();
  }

  class Gate extends Thread {
    public void run() {
      for (int i = 0; i < PEOPLE; i++) {
        try {
          sem.acquire(); // Entry protocol
          counter++;     // Critical section
          sem.release(); // Exit protocol
        } catch(InterruptedException e) {
          System.out.println(e);
        }
      }
    }
  }
}
