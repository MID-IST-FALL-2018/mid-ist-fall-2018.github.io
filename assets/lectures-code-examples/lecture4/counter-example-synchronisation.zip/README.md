# Synchronisation of the Counter example

Here are a series of different examples showing how to guarantee mutual
exclusion during the execution of the operation `counter++` in `Counter.java`.

* Locks
  * `CounterLocks.java` - Solution using `ReentrantLock`
  * `CounterSynchronized.java` & `CounterSynchronizedBlock.java` - Solution using the intrinsic lock that all Java objects contain. Using synchronized methods and synchronized blocks, respectively.

* Semaphores
  * `ConterSemaphores.java` - Using semaphores that only allow one thread in the critical section.
  * `ConterSemaphoresCoffee.java` - Variation where if the semaphores is not free, the threads go to sleep and try again. It uses `tryAcquire()`.

# Running the code

To run the code compile with

```bash
$ javac *.java
```

and run the java program that you choose as follows (example for `CounterLocks`)

```bash
$ java CounterLocks
```

The file `run.sh` is a simple script that runs the program 10 times. Note that
the program to run is hardcoded in the script. In order to change the program to
run you must change the name of the program (i.e., line 5 of the script).
