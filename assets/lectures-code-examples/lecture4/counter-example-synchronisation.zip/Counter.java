/*
 * Author: Raúl Pardo
 */

class Counter {
    int counter = 0; // Counter indicating the number of people that enter the metro
    final int PEOPLE = 10000; // Number of people to cross each gate

    public Counter() {
        try {
            // Initialising the east gate
            Gate east = new Gate();

            // Initialising the west gate
            Gate west = new Gate();

            // Start the gate threads
            east.start();west.start();

            // Wait until the threads have finished
            east.join();west.join();

            // Print the final result of `counter`
            System.out.println("counter = " + counter);

        } catch (InterruptedException e) { // Thread methods such as `start()` or `join()` may through `InterruptedException`
            System.out.println(e);
        }
    }

    // Here we start the program
    public static void main(String[] args) {
        new Counter();
    }

    // Class gate which models people crossing a gate
    class Gate extends Thread {

        // The `run()` method is executed when calling `start()`
        public void run() {
            for (int i = 0; i < PEOPLE; i++) {
                counter++; // Critical section
            }
        }
    }
}
