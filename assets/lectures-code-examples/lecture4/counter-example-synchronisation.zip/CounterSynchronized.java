class CounterSynchronized {
  final int PEOPLE = 1000;
  Counter c = new Counter(); // Thread-safe counter

  public CounterSynchronized() {
    try {
      Gate east = new Gate();
      Gate west = new Gate();

      east.start();west.start();
      east.join();west.join();

      System.out.println("counter = " + c.getCounter());

    } catch (InterruptedException e) {
      System.out.println(e);
    }

  }

  public static void main(String[] args) {
    new CounterSynchronized();
  }

  class Gate extends Thread {
    public void run() {
      for (int i = 0; i < PEOPLE; i++) {
        c.inc();
      }
    }
  }

  class Counter {
    private int counter;

    public Counter() {
      counter=0;
    }

    public synchronized void inc() {
      counter++;
    }

    public int getCounter() {
      return counter;
    }
  }
}
