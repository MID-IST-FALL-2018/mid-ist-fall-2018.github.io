import java.util.concurrent.Semaphore; // Semaphores library for Java

class CounterSemaphoresCoffee {
  int counter = 0;
  final int PEOPLE = 1000;
  Semaphore sem = new Semaphore(1);

  public CounterSemaphoresCoffee() {
    try {
      Person[] person = new Person[PEOPLE];
      for (int i = 0; i < PEOPLE; i++) {
        person[i] = new Person();
        person[i].start();
      }

      for (int i = 0; i < PEOPLE; i++) {
        person[i].join();
      }

      System.out.println("counter = " + counter);

    } catch (InterruptedException e) {
      System.out.println(e);
    }

  }

  public static void main(String[] args) {
    new CounterSemaphoresCoffee();
  }

  class Person extends Thread {
    public void run() {
      Boolean enter = false;
      while (!enter) {
        if (sem.tryAcquire()) { // Check if there is anyone in the queue,
                                // if not enter, i.e., acquire the semaphore
                                // (everything is done atomically)!
          counter++; // critical section
          sem.release(); // Release critical section
          enter = true;
        } else {
          // Going for a coffee and come back later
          try{Thread.sleep(500);}catch(InterruptedException e){}
        }
      }
    }
  }
}
