import java.util.concurrent.locks.Lock; // Lock library for Java
import java.util.concurrent.locks.ReentrantLock; // Lock library for Java

class CounterLocks {
    int counter = 0;
    final int PEOPLE = 1000;
    Lock lock = new ReentrantLock();

    public CounterLocks() {
        try {
            Gate east = new Gate();
            Gate west = new Gate();

            east.start();west.start();
            east.join();west.join();

            System.out.println("counter = " + counter);

        } catch (InterruptedException e) {
            System.out.println(e);
        }

    }

    public static void main(String[] args) {
        new CounterLocks();
    }

    class Gate extends Thread {
        public void run() {
            for (int i = 0; i < PEOPLE; i++) {
                lock.lock();   // Entry protocol
                try {
                  counter++;   // Critical section
                } finally { // Always executes the exit protocol
                            // even if an exception is thrown
                  lock.unlock(); // Exit protocol
                }
            }
        }
    }
}
