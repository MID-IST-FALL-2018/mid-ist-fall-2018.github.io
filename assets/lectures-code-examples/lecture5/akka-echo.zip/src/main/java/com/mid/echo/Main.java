package com.mid.echo;

// Java libraries
import java.io.IOException;

// Actor imports
import com.mid.echo.Client.TellServer;
import com.mid.echo.Server.Shutdown;

// Akka libraries
import akka.actor.ActorRef;
import akka.actor.ActorSystem;

public class Main {
  public static void main(String[] args) {
    // Initialise the actor system
    final ActorSystem system = ActorSystem.create("akka-echo");
    try {

      // Create actors (start threads)
      final ActorRef server = system.actorOf(Server.props(), "server_actor");
      final ActorRef client = system.actorOf(Client.props(server), "client_actor");

      // Send asynchronous message to client
      client.tell(new TellServer("hi"), ActorRef.noSender());

      // Small delay to give time to the Client to send the message to the server
      // Comment to see the efect that may have
      try{Thread.sleep(1000);}catch(Exception e){}

      // Send asynchronous message to server to shutdown
      server.tell(new Shutdown(), ActorRef.noSender());

      System.out.println(">>> Press ENTER to exit <<<");
      System.in.read();
    } catch (IOException ioe) {
      System.out.println("Exception: " + ioe);
    } finally {
      system.terminate();
    }
  }
}
