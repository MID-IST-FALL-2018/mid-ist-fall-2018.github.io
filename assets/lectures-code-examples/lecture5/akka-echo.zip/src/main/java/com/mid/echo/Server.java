package com.mid.echo;

import com.mid.echo.Client.ResponseServer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Server extends AbstractActor {


  /***********/
  /** State **/
  /***********/
  // Empty


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props() {
    return Props.create(Server.class, () -> new Server());
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Server() {}


  /**************/
  /** Messages **/
  /**************/
  static public class Shutdown {
    public Shutdown() {}
  }


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // String message received
    .match(String.class, st -> {
      getSender().tell(new ResponseServer(st), getSelf());
    })
    // Shutdown the server
    .match(Shutdown.class, x -> {
      System.out.println("Shutting down server...");
      getContext().stop(getSelf());
    })
    .build();
  }
}
