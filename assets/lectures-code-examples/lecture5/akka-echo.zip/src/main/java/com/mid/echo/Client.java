package com.mid.echo;

import java.util.List;
import java.util.ArrayList;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Client extends AbstractActor {


  /***********/
  /** State **/
  /***********/
  ActorRef server;


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props(ActorRef server) {
    return Props.create(Client.class, () -> new Client(server));
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Client(ActorRef server) {
    this.server = server;
  }


  /**************/
  /** Messages **/
  /**************/
  static public class TellServer {
    public String message;
    public TellServer(String message) {
      this.message = message;
    }
  }
  static public class ResponseServer {
    public String response;
    public ResponseServer(String response) {
      this.response = response;
    }
  }


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // String message received
    .match(TellServer.class, ts -> {
      System.out.println("Sending: " + ts.message);
      server.tell(ts.message, getSelf());
    })
    .match(ResponseServer.class, rs -> {
      System.out.println("Echo: " + rs.response);
    })
    .build();
  }
}
