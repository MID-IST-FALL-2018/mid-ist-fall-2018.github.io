package com.mid.echo;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mid.echo.Server;
import com.mid.echo.Client.ResponseServer;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.testkit.javadsl.TestKit;

public class EchoServerTest {
  static ActorSystem system;

  // Start the actor system
  @BeforeClass
  public static void start() {
      system = ActorSystem.create();
  }

  // Shutdown the actor system
  @AfterClass
  public static void shutdown() {
      TestKit.shutdownActorSystem(system);
      system = null;
  }

  @Test
  public void test() {
    // Create a dummy actor, testProb, as synthetic client
    final TestKit testProbe = new TestKit(system);
    // Create a server actor
    final ActorRef server = system.actorOf(Server.props());
    // Tell client to send a message to server
    String messageToSend = "test";
    server.tell(messageToSend, testProbe.getRef());
    // Check that the server replies with the expected message type
    ResponseServer rs = testProbe.expectMsgClass(ResponseServer.class);
    // Check that the content of the message is the one we originally sent
    assertEquals(messageToSend, rs.response);
  }
}
