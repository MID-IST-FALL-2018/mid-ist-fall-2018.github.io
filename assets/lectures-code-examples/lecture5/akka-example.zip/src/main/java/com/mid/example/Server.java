package com.mid.example;

import java.util.List;
import java.util.ArrayList;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Server extends AbstractActor {


  /***********/
  /** State **/
  /***********/
  List<String> history;


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props() {
    return Props.create(Server.class, () -> new Server());
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Server() {
    history = new ArrayList<String>();
  }


  /**************/
  /** Messages **/
  /**************/
  static public class PrintHistory {
    public int number;
    public PrintHistory(int number) {
      this.number = number;
    }
  }


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // String message received
    .match(String.class, st -> {
      System.out.println("Message recorded: " + st);
      history.add(st);
    })
    // Print history message received
    .match(PrintHistory.class, ph -> {
      System.out.println("== Beginning History ==");
      for(int i = 0;
          i < ph.number && i < history.size();
          i++) {
        System.out.println("Received message: " + history.get(i));
      }
      System.out.println("== End History ==");
    })
    .build();
  }
}
