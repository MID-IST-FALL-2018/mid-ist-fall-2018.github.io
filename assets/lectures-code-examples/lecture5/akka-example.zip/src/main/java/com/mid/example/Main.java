package com.mid.example;

// Java libraries
import java.io.IOException;

// Actor imports
import com.mid.example.Server.PrintHistory;

// Akka libraries
import akka.actor.ActorRef;
import akka.actor.ActorSystem;

public class Main {
  public static void main(String[] args) {
    // Initialise the actor system
    final ActorSystem system = ActorSystem.create("akka-example");
    try {

      // Create actors (start threads)
      final ActorRef server = system.actorOf(Server.props(), "server_actor");

      // Send asynchronous message to server of type `String`
      server.tell("Hi", ActorRef.noSender());
      server.tell("Hallo", ActorRef.noSender());
      server.tell("Dzień dobry", ActorRef.noSender());
      server.tell("Ciao", ActorRef.noSender());
      server.tell("Hola", ActorRef.noSender());

      // Send asynchronous message to server of type `PrintHistory`
      server.tell(new PrintHistory(3), ActorRef.noSender());

      System.out.println(">>> Press ENTER to exit <<<");
      System.in.read();
    } catch (IOException ioe) {
      System.out.println("Exception: " + ioe);
    } finally {
      // Terminates all actors
      system.terminate();
    }
  }
}
