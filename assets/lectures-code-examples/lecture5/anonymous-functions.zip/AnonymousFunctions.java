import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

class AnonymousFunctions {
  public static void main(String[] args) {

    // Example 1: Definition and basic usage
    // f : Integer -> Integer
    // f(x) = x
    Function<Integer,Integer> f = (i) -> i;
    System.out.println(""+f.apply(1));



    // Example 2: More concise syntax
    String[] farewells = {"Goodbye",
                          "Auf Wiedersehen",
                          "Adiós",
                          "Addio",
                          "Do widzenia"};

    System.out.println("== Print before ordering ==");
    System.out.println(Arrays.toString(farewells));

    System.out.println("== Print after ordering ==");

    // Using anonymous functions
    Arrays.sort(farewells, (a,b) -> a.length() - b.length());

    // Without anonymous functions
    Arrays.sort(farewells, new Comparator<String>() {
                                  @Override
                                  public int compare(String a, String b) {
                                    return(a.length() - b.length());
                                  }
    });
    System.out.println(Arrays.toString(farewells));




    // Example 3: Easy to paralellise
    List<Integer> numbers = new ArrayList<Integer>();
    numbers.add(1);numbers.add(2);numbers.add(3);

    // Sequential                                        // Grouping operation.
                                                         // In this case simply
                                                         // creates a list of arrays
    List<Integer> result = numbers.stream().map(x -> x+2).collect(Collectors.toList());
    System.out.println(Arrays.toString(result.toArray()));

    // Parallel
    result = numbers.parallelStream().map(x -> x+2).collect(Collectors.toList());
    System.out.println(Arrays.toString(result.toArray()));

    // BTW, we can use the function f(x)=x defined above
    result = numbers.parallelStream().map(f).collect(Collectors.toList());
    System.out.println(Arrays.toString(result.toArray()));
  }
}
