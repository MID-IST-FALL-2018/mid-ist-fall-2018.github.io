package com.mid.math.workers;

import com.mid.math.workers.Client.ResponseServer;
import com.mid.math.workers.Server.OperationDone;
import com.mid.math.workers.BinaryOperation;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Worker extends AbstractActor {

  /***********/
  /** State **/
  /***********/
  ActorRef server;


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props(ActorRef server) {
    return Props.create(Worker.class, () -> new Worker(server));
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Worker(ActorRef server) {
    this.server = server;
  }


    /**************/
    /** Messages **/
    /**************/
    static public class PerformTask {
      int x,y;
      BinaryOperation op;
      ActorRef senderClient;


      public PerformTask(int x, int y, BinaryOperation op, ActorRef senderClient) {
        this.x            = x;
        this.y            = y;
        this.op           = op;
        this.senderClient = senderClient;
      }
    }

    static public class Shutdown {
      public Shutdown() {}
    }


      /*********************/
      /** Message handler **/
      /*********************/
      @Override
      public Receive createReceive() {
        return receiveBuilder()
        // String message received
        .match(PerformTask.class, pt -> {
          int result = Integer.MIN_VALUE;
          switch (pt.op) {
            case SUM:
              // try{Thread.sleep(5000);}catch(Exception e){} // Delay for task
              result = pt.x + pt.y;
              break;
            case SUB:
              result = pt.x - pt.y;
              break;
            case MUL:
              result = pt.x * pt.y;
              break;
          }
          getSender().tell(new OperationDone(result,pt.senderClient), getSelf());
        })
        // Shutdown the worker
        .match(Shutdown.class, x -> {
          System.out.println("Shutting down worker: " + getSelf());
          getContext().stop(getSelf());
        })
        .build();
      }
    }
