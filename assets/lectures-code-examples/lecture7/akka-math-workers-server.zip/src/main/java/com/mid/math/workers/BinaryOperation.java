package com.mid.math.workers;

enum BinaryOperation {SUM, SUB, MUL};
