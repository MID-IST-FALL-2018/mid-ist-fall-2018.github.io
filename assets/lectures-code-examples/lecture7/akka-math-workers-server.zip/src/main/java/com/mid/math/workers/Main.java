package com.mid.math.workers;

// Java libraries
import java.io.IOException;

// Actor imports
import com.mid.math.workers.Client.StartMessage;
import com.mid.math.workers.Server.Shutdown;

// Akka libraries
import akka.actor.ActorRef;
import akka.actor.ActorSystem;

public class Main {
  public static void main(String[] args) {
    // Initialise the actor system
    final ActorSystem system = ActorSystem.create("akka-math-workers");
    try {

      // Create actors (start threads)
      final ActorRef server = system.actorOf(Server.props(), "server_actor");
      final ActorRef client = system.actorOf(Client.props(server), "client_actor");

      // Send asynchronous message to client
      client.tell(new StartMessage(), ActorRef.noSender());

      System.out.println(">>> Press ENTER to exit <<<");
      System.in.read();
    } catch (IOException ioe) {
      System.out.println("Exception: " + ioe);
    } finally {
      system.terminate();
    }
  }
}
