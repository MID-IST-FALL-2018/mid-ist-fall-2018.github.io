package com.mid.math.workers;

import com.mid.math.workers.Client.ResponseServer;
import com.mid.math.workers.Worker.PerformTask;
import com.mid.math.workers.BinaryOperation;


import java.util.Queue;
import java.util.LinkedList;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Server extends AbstractActor {

  /***********/
  /** State **/
  /***********/
  Queue<ActorRef> workers;
  Queue<PerformTask> pendingRequests;


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props() {
    return Props.create(Server.class, () -> new Server());
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Server() {
    pendingRequests = new LinkedList<PerformTask>();
    workers = new LinkedList<ActorRef>();
    for (int i=0; i < 3 ; i++) {
      workers.add(getContext().actorOf(Worker.props(getSelf())));
    }
  }


  /**************/
  /** Messages **/
  /**************/
  static public class RequestOperation {
    int x,y;
    BinaryOperation op;

    public RequestOperation(int x, int y, BinaryOperation op) {
      this.x  = x;
      this.y  = y;
      this.op = op;
    }
  }

  static public class OperationDone {
    int result;
    ActorRef sender;

    public OperationDone(int result, ActorRef sender) {
      this.result  = result;
      this.sender  = sender;
    }
  }

  static public class Shutdown {}


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // String message received
    .match(RequestOperation.class, ro -> {
      if(!workers.isEmpty()) {
        ActorRef worker = workers.remove();
        worker.tell(new PerformTask(ro.x,ro.y,ro.op,getSender()), getSelf());
      } else {
        // Put in pending tasks
        pendingRequests.add(new PerformTask(ro.x,ro.y,ro.op, getSender()));
      }
    })
    // Receive task from worker
    .match(OperationDone.class, od -> {
      od.sender.tell(new ResponseServer(od.result),getSelf());
      if(!pendingRequests.isEmpty()) {
        PerformTask pt = pendingRequests.remove();
        getSender().tell(new PerformTask(pt.x,pt.y,pt.op,pt.senderClient), getSelf());
      } else {
        workers.add(getSender());
      }
    })
    // Shutdown the server
    .match(Shutdown.class, x -> {
      System.out.println("Shutting down server...");
      getContext().stop(getSelf());
    })
    .build();
  }
}
