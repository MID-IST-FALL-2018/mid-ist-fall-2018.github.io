package com.mid.timers;

// Java libraries
import java.io.IOException;

// Akka libraries
import akka.actor.ActorRef;
import akka.actor.ActorSystem;

public class Main {
  public static void main(String[] args) {
    // Initialise the actor system
    final ActorSystem system = ActorSystem.create("akka-timers");
    try {
      // Create actors (start threads)
      final ActorRef client = system.actorOf(MyActor.props(), "client_actor");

      System.out.println(">>> Press ENTER to exit <<<");
      System.in.read();
    } catch (IOException ioe) {
      System.out.println("Exception: " + ioe);
    } finally {
      system.terminate();
    }
  }
}
