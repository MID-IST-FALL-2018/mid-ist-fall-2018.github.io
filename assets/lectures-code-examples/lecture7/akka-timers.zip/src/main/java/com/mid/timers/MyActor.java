package com.mid.timers;

import java.util.List;
import java.util.ArrayList;
import java.time.Duration;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.AbstractActorWithTimers;
import akka.actor.ReceiveTimeout;

public class MyActor extends AbstractActorWithTimers {


  /***********/
  /** State **/
  /***********/
  // Empty state


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props() {
    return Props.create(MyActor.class, () -> new MyActor());
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public MyActor() {
    // Start a timer that sends a message of type TimerMessage every 3 seconds
    getTimers().startPeriodicTimer("MyTimer", new TimerMessage(), Duration.ofSeconds(1));
    // getContext().setReceiveTimeout(Duration.ofSeconds(3)); // Uncomment for timeout
  }


  /**************/
  /** Messages **/
  /**************/
  static public class TimerMessage {}



  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // Timer message received
    .match(TimerMessage.class, tm -> {
      System.out.println("Timer signal received.");
    })
    .match(ReceiveTimeout.class, rt -> {
      System.out.println("Timeout received.");
    })
    .build();
  }
}
