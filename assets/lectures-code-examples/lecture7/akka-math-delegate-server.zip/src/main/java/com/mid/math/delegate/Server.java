package com.mid.math.delegate;

import com.mid.math.delegate.Client.ResponseServer;
import com.mid.math.delegate.Worker.PerformTask;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Server extends AbstractActor {

  /***********/
  /** State **/
  /***********/
  // Empty


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props() {
    return Props.create(Server.class, () -> new Server());
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Server() {}


  /**************/
  /** Messages **/
  /**************/
  static public class RequestOperation {
    int x,y;
    BinaryOperation op;

    public RequestOperation(int x, int y, BinaryOperation op) {
      this.x  = x;
      this.y  = y;
      this.op = op;
    }
  }

  static public class OperationDone {
      int result;
      ActorRef sender;

      public OperationDone(int result, ActorRef sender) {
        this.result  = result;
        this.sender  = sender;
      }
    }

  static public class Shutdown {
    public Shutdown() {}
  }


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // String message received
    .match(RequestOperation.class, ro -> {
      ActorRef worker = getContext().actorOf(Worker.props(getSelf()));
      worker.tell(new PerformTask(ro.x,ro.y,ro.op, getSender()), getSelf());
    })
    .match(OperationDone.class, od -> {
      od.sender.tell(new ResponseServer(od.result),getSelf());
      getContext().stop(getSender());
    })
    // Shutdown the server
    .match(Shutdown.class, x -> {
      System.out.println("Shutting down server: Hasta la vista 😎");
      getContext().stop(getSelf());
    })
    .build();
  }
}
