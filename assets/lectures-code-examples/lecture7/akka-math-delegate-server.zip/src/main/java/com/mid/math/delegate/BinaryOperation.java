package com.mid.math.delegate;

enum BinaryOperation {SUM, SUB, MUL, PI_DIGITS};
