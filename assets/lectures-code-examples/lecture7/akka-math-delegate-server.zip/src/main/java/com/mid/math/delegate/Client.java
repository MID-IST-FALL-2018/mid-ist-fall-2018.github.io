package com.mid.math.delegate;

import com.mid.math.delegate.Server.RequestOperation;
import com.mid.math.delegate.Server.Shutdown;

import java.util.List;
import java.util.ArrayList;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class Client extends AbstractActor {


  /***********/
  /** State **/
  /***********/
  ActorRef server;


  /*******************/
  /** Configuration **/
  /*******************/
  static public Props props(ActorRef server) {
    return Props.create(Client.class, () -> new Client(server));
  }


  /*****************/
  /** Constructor **/
  /*****************/
  public Client(ActorRef server) {
    this.server = server;
  }


  /**************/
  /** Messages **/
  /**************/
  static public class StartMessage {}

  static public class ResponseServer {
    public int response;
    public ResponseServer(int response) {
      this.response = response;
    }
  }


  /*********************/
  /** Message handler **/
  /*********************/
  @Override
  public Receive createReceive() {
    return receiveBuilder()
    // Start message
    .match(StartMessage.class, ts -> {
      // for (int i=0; i<500000; i++) { // What happens if we send 15000000 messages i a row?
        System.out.println("Asking server to compute 1+2");
        server.tell(new RequestOperation(1, 2, BinaryOperation.SUM), getSelf());
        System.out.println("Asking server to compute 0-23");
        server.tell(new RequestOperation(0, 23, BinaryOperation.SUB), getSelf());
        System.out.println("Asking server to compute 2*4");
        server.tell(new RequestOperation(2, 4, BinaryOperation.MUL), getSelf());
        // server.tell(new Shutdown(), getSelf()); // What happens if we uncomment this line?
      // }
    })
    .match(ResponseServer.class, rs -> {
      System.out.println("Result: " + rs.response);
    })
    .build();
  }
}
